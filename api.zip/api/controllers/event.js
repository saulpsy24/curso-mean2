'use strict'
var path = require('path');
var fs = require('fs');
var mongoosePaginate = require('mongoose-pagination');
var Evento = require('../models/event');
var Sala = require('../models/sala');
var Dossiere = require('../models/dossiere');
var Eventos = require('../models/event');
var Espacio = require('../models/espacio');
var Asist = require('../models/assistant');
var Turno = require('../models/turno');

function getEvent(req, res) {
      var idEvent = req.params.id;

    Evento.findById(idEvent).populate({
        path: 'space'
    }).exec((err, event) => {
        if (err) {
            res.status(500).send({
                message: 'error en la peticion'
            });
        } else {
            if (!event) {
                res.status(404).send({
                    message: 'No existe el evento'
                });
            } else {
                res.status(200).send({
                    event
                });
            }
        }
    });
}


  
//metodo para guardar artista sin imagen
function saveEvent(req, res) {
    var event = new Evento();
    var params = req.body;
    
    event.title=params.title;
    event.description= params.description;
    event.brand=params.brand;
    event.space=params.space;
   

    event.save((err, eventStored) => {
        if (err) {
            res.status(500).send({
                message: 'Error'
            });

        } else {
            if (!eventStored) {
                res.status(404).send({
                    message: 'No se guardo evento'
                });
            } else {
                res.status(200).send({
                    event: eventStored
                });
            }
        }
    });
}
//Metodo para ver artistas por pagina
function getEvents(req, res) {
    var eventId = req.params.space;
    if (!eventId) {
        //sacar todos los albums de la DB
        var find = Evento.find({}).sort('name');
    } else {
        //mostrar solamente los albums de ese artista
        var find = Evento.find({
            event: eventId
        }).sort('name');
    }
    find.populate({
        path: 'space',       
        
    }).exec((err, eventos) => {
        if (err) {
            res.status(500).send({
                message: 'error'
            });
        } else {
            if (!eventos) {
                res.status(404).send({
                    message: 'no hay eventos asociadas'
                });
            } else {
                res.status(200).send({
                    event: eventos
                });
            }
        }
    });
}
//metodo para actualizar artistas
function updateEvent(req, res) {
    var eventId = req.params.id;
    var update = req.body;

    Evento.findByIdAndUpdate(eventId, update, (err, eventUpdated) => {
        if (err) {
            res.status(500).send({
                message: 'Error al actualizar Evento'
            });
        } else {
            if (!eventUpdated) {
                res.status(404).send({
                    message: 'No se pudo actualizar evento'
                });

            } else {
                res.status(200).send({
                    event: eventUpdated
                });

            }
        }
    });
}

//METODO PARA BORRAR ARTISTAS
function deleteEvent(req, res) {
    var eventId = req.params.id;
    Evento.findByIdAndRemove(eventId, (err, eventRemoved) => {
        if (err) {
            res.status(500).send({
                message: 'Error al borrar Evento'
            });
        } else {
            if (!eventRemoved) {
                res.status(404).send({
                    message: 'Evento no  se pudo eliminar'
                });
            } else {


                Turno.find({
                    event: eventRemoved._id
                }).remove((err, turnoRemoved) => {
                    if (err) {
                        res.status(500).send({
                            message: 'Error al borrar Album'
                        });
                    } else {
                        if (!turnoRemoved) {
                            res.status(404).send({
                                message: 'Turno no  se pudo eliminar'
                            });
                        } else {
                            Asist.find({
                                turno: turnoRemoved._id
                            }).remove((err, asistRemoved) => {
                                if (err) {
                                    res.status(500).send({
                                        message: 'Error al borrar Asistencia'
                                    });
                                } else {
                                    if (!asistRemoved) {
                                        res.status(404).send({
                                            message: 'asistencia no  se pudo eliminar'
                                        });
                                    } else {
                                        res.status(200).send({
                                            event: eventRemoved
                                        });

                                    }
                                }
                            });

                        }
                    }
                });
            }

        }
    });
}




module.exports = {
    getEvent,
    saveEvent,
    getEvents,
    updateEvent,
    deleteEvent

    
};