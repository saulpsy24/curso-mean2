'use strict'
//IMPORTANDO LIBRERIAS
var Cliente = require('../models/cliente');
var bcrypt = require('bcrypt-nodejs');
var jwt = require('../services/jwt');
var fs = require('fs');
var path = require('path');


//METODO PARA registro/login USUARIOS
function savecliente(req, res) {
    var cliente = new Cliente();

    var params = req.body;
    cliente.name = params.name;
    cliente.surname = params.surname;
    cliente.email = params.email;
    cliente.role = 'ROLE_ADMIN';
    cliente.image = 'null';
    cliente.nameEstablishment= params.nameEstablishment;
    cliente.code =params.code;
    cliente.phone= params.phone;
    cliente.zip= params.zip;
    cliente.province= params.province;
    cliente.nifCif= params.nifCif;
    cliente.street= params.street;
    cliente.brandV= params.brandV;
    cliente.brandRG=params.brandRG;
    cliente.brandSK=params.brandSK;
    cliente.brandLR=params.brandLR;
    var email = cliente.email;
    var password = "FormacionesCAE";

    //validando que el correo no esta registrado

    Cliente.findOne({
        'email': email
    }, function (err, elements) {

        if (err) {
            res.status(500).json({
                error: false,
                message: err.message
            });
        }
        if (!elements) {

            if (password) {
                //ecnriptar pasword
                bcrypt.hash(password, null, null, function (err, hash) {
                    cliente.password = hash;

                    if (cliente.name != null && cliente.surname != null && cliente.email != null) {
                        //guardar en DB

                        cliente.save((err, clienteStored) => {
                            if (err) {
                                res.status(500).send({
                                    message: 'No se gurdaron datos'
                                });

                            } else {
                                if (!clienteStored) {
                                    res.status(404).send({
                                        message: 'No se registro a nadie'
                                    });
                                } else {
                                    res.status(200).send({
                                        cliente: clienteStored,

                                    });
                                }

                            }


                        });
                    } else {
                        res.status(500).send({
                            message: 'Faltan datos'
                        });
                    }


                });
            } else {
                res.status(500).send({
                    message: 'Introduce el pass',

                });
            }

        } else {
            //si ya esta registrado loguear
            cliente.password='FormacionesCAE';
            params.gethash = true;
            Cliente.findOne({
                email: email.toLowerCase()
            }, (err, cliente) => {
                if (err) {
                    res.status(500).send({
                        message: 'Error en la peticion'
                    });
                } else {
                    if (!cliente) {
                        res.status(404).send({
                            message: 'Usuario no existe'
                        });
                    } else {
                        //checar password
                        bcrypt.compare(password, cliente.password, function (err, check) {
                            if (check) {
                                //devolver datos de ususario logueado
                                if (params.gethash) {
                                    //devolver un token jwt
                                    res.status(200).send({
                                        token: jwt.createToken(cliente),
                                        
                                    });

                                } else {
                                    res.status(200).send({
                                        cliente
                                    });
                                }
                            } else {
                                res.status(404).send({
                                    message: 'Usuario no pudo loggear'
                                });
                            }
                        });
                    }
                }

            });
        }


    });

}
//METODO PARA ACTUALIZAR USUARIOS
function updatecliente(req, res) {
    var clienteId = req.params.id;
    var update = req.body;

    if (update.password) {
        //ecnriptar pasword
        bcrypt.hash(update.password, null, null, function (err, hash) {
            var cliente = hash;
            update.password = cliente;


            Cliente.findByIdAndUpdate(clienteId, update, (err, clienteUpdated) => {
                if (err) {
                    res.status(500).send({
                        message: 'Error al actualizar usuario'
                    });
                } else {
                    if (!clienteUpdated) {
                        res.status(404).send({
                            message: 'No se pudo actualizar usuario'
                        });

                    } else {
                        res.status(200).send({
                            cliente: clienteUpdated
                        });

                    }
                }
            });
        });

    } else {
        Cliente.findByIdAndUpdate(clienteId, update, (err, clienteUpdated) => {
            if (err) {
                res.status(500).send({
                    message: 'Error al actualizar usuario'
                });
            } else {
                if (!clienteUpdated) {
                    res.status(404).send({
                        message: 'No se pudo actualizar usuario'
                    });

                } else {
                    res.status(200).send({
                        cliente: clienteUpdated
                    });

                }
            }
        });
    }

}
function logincliente(req,res){
    var params = req.body;
    var email = params.email;
    var password = params.password;
    Cliente.findOne({
        email: email.toLowerCase()
    }, (err, cliente) => {
        if (err) {
            res.status(500).send({
                message: 'Error en la peticion'
            });
        } else {
            if (!cliente) {
                res.status(404).send({
                    message: 'Usuario no existe'
                });
            } else {
                //checar password
                bcrypt.compare(password, cliente.password, function (err, check) {
                    if (check) {
                        //devolver datos de ususario logueado
                        if (params.gethash) {
                            //devolver un token jwt
                            res.status(200).send({
                                token: jwt.createToken(cliente),
                            });

                        } else {
                            res.status(200).send({
                                cliente
                            });
                        }
                    } else {
                        res.status(404).send({
                            message: 'Usuario no pudo loggear'
                        });
                    }
                });
            }
        }

    });
}
module.exports = {
    savecliente,
    updatecliente,
    logincliente
}
