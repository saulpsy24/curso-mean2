import { ModuleWithProviders} from '@angular/core';
import { Routes, RouterModule } from '@angular/router';



import { ClienteEditComponent } from './components/cliente_edit.component';

const appRoutes: Routes = [
    
    {path: '',component:ClienteEditComponent},
    {path:'mis-datos', component:ClienteEditComponent},
    {path:'**', component:ClienteEditComponent}
];

export const appRoutingProviders: any[] = [];
export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);