import { Component, OnInit } from '@angular/core';
import { ClienteService } from '../services/cliente.service';
import { Cliente } from '../models/cliente';

@Component({

    selector: 'cliente-edit',
    templateUrl: '../views/cliente-edit.html',
    providers: [ClienteService]
})

export class ClienteEditComponent implements OnInit {
    public titulo: String;
    public cliente: Cliente;
    public identity;
    public token;
    public AlertMessage;

    constructor(
        private _clienteService: ClienteService
    ) {
        this.titulo = 'Actualizar datos de Usuario';

        //LocalStorage
        
        this.cliente = this.identity;

    }

    ngOnInit() {
        this.token = this._clienteService.getToken();
        this.identity = this._clienteService.getidentity();

        this.cliente=this.identity;
    }
    onSubmit(){
        
        this._clienteService.update_cliente(this.cliente).subscribe(
            response =>{
               // this.cliente = response.cliente;
                if(!response.cliente){
                    this.AlertMessage ='El usuario no se ha actualizado';
                }else{
                    this.AlertMessage ='El usuario se ha actualizado';
                    
                    localStorage.setItem('identity',JSON.stringify(this.cliente));
                   
                }


            },
            error=>{
                
                var errorMessage = <any>error;
                if (errorMessage != null) {
                    var body = JSON.parse(error._body);
                    this.AlertMessage = body.message;
                    console.log(error);
            }
        }
        );
    }
}