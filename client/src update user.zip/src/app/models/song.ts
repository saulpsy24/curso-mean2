export class Song{
    constructor(
    public number: number,
     public name: string,
     public duration: string,
     public album: string,     
     public file: string
     
    ){}
}