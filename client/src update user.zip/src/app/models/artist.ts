export class Artist{
    constructor(
     public name: string,
     public description: string,     
     public image: string
     
    ){}
}