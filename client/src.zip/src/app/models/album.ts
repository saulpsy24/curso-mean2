export class Album{
    constructor(
   
     public title: string,
     public description: string,    
     public artist: string,
      public year:number,
      public image:string
     
    ){}
}