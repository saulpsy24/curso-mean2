
export class Cliente{
    constructor(
    public _id: String,
     public name: string,
     public nameEstablishment: string,
     public surname: string,
     public email: string,
     public code: string,
     public image: String,
     public phone: string,
     public zip: string,
     public province: string,
     public nifCif: string,
     public street: string,
     public brandV: string,
     public brandLR: string,
     public brandRG: string,
     public brandSK: string,
     public password: string
    ){}
}