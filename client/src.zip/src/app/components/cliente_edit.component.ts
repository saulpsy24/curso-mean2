import { Component, OnInit } from '@angular/core';
import{ClienteService} from '../services/cliente.service';
import {Cliente} from  '../models/cliente';

@Component({
    
    selector: 'cliente-edit',
    templateUrl: '../views/cliente-edit.html',
    providers: [ClienteService]
})

export class ClienteEditComponent implements OnInit{
    public titulo: String;
    public cliente:Cliente;
    public identity;
    public token;
    
    constructor(
    private _clienteService: ClienteService
    ){
        this.titulo ='Actualizar datos de Usuario';
    }
    ngOnInit(){
         this.token= this._clienteService.getToken();
        this.identity = this._clienteService.getidentity();
        console.log('component de edicion cargado');
    }
}