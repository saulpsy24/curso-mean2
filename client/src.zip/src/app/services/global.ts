export var GLOBAL = {
  url: 'http://localhost:3977/api/',
  ip:'127.0.0.1'    
};